# particledist

This is a package for analyzing event mass distributions and automating the search for new particles.
